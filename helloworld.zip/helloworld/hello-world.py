
def helloworld():
    print("what is a fork, it is too difficult,i am going crazy, i want to go to home and sleep.")


if __name__ == "__main__":
    helloworld()

