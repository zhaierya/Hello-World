how to upload a dictionary? 
so confusing!